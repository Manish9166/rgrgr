# ConversOrbit SaaS Platform
> **AI Conversations. Automated Growth.**  
> WhatsApp automation, customer communication, CRM, chatbot, marketing campaigns, and workflow automation SaaS.

## Overview
ConversOrbit is an enterprise-grade multi-tenant B2B SaaS platform engineered for brands and support organizations to automate inbound and outbound customer communication via WhatsApp, AI chatbots, and multi-step workflows.

## Key Features
- **Public B2B Portal**: 13 comprehensive public pages (Home, Features, Pricing, Use Cases, About, Contact, Login, Signup, Forgot Password, Privacy, Terms, Refund, Help/FAQ).
- **Tenant Isolation**: Secure multi-tenant architecture with isolated workspaces for every customer organization.
- **Shared Inbox**: Real-time agent collaboration, canned replies, internal notes, tag management, and WhatsApp message streams.
- **Contacts CRM**: Full CRUD, CSV Import with validation and duplicate detection, CSV export, and filtering.
- **Campaign Manager**: Multi-step broadcast creator, audience segmentation, variable interpolation (`{{name}}`), live dispatch simulation, and performance reports.
- **Visual Chatbot Builder**: Node-based logic editor, keyword triggers, buttons, and live mobile phone simulator for instant testing.
- **Workflow Automation**: Trigger-Condition-Action automation engine with step-by-step test execution and audit logs.
- **Analytics**: Tabular and graphic reporting for messages, response times, bot resolutions, and campaign conversions.
- **Team RBAC**: Role-based permissions (Super Admin, Owner, Admin, Agent, Viewer).
- **Subscription & Billing**: Plan comparison matrix, quota meters, simulated Stripe checkout, and invoice ledger.
- **Super Admin Console**: Dedicated platform management area for tenants, plans, integration health, audit logs, and support tickets.
- **Dual Mode WhatsApp**: Seamless switching between Simulated Sandbox Demo Mode and Live Meta Cloud API mode.

## Quick Start
```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env.local

# 3. Start local development server
npm run dev
```
Visit http://localhost:3000 to interact with the platform.
