# ConversOrbit Deployment Guide

## Production Architecture Options
1. **Frontend & Backend**: Next.js or Node.js Express + React on Vercel, Railway, AWS ECS, or Google Cloud Run.
2. **Database**: Managed PostgreSQL (Supabase, Neon, AWS RDS, or Cloud SQL).
3. **WhatsApp Provider**: Official Meta for Developers WhatsApp Cloud API v19.0+.
4. **Email Dispatch**: Resend or AWS SES.
5. **Billing**: Stripe Billing & Webhooks.

## Step-by-Step Production Setup

### 1. Database Provisioning
1. Create a PostgreSQL instance in Supabase, Neon, or Cloud SQL.
2. Run `db/schema.sql` using the SQL Editor to provision all tables, indexes, and Row Level Security policies.
3. Configure connection pooling in `DATABASE_URL`.

### 2. WhatsApp Cloud API Configuration
1. Go to [Meta for Developers](https://developers.facebook.com/) and create a Business App.
2. Add the **WhatsApp** product.
3. In **API Setup**, retrieve your:
   - Phone Number ID
   - WhatsApp Business Account ID (WABA ID)
   - System User Access Token (with `whatsapp_business_messaging` permissions)
4. Set Webhook URL to: `https://your-domain.com/api/webhooks/whatsapp`
5. Provide your `WHATSAPP_WEBHOOK_VERIFY_TOKEN`.
6. Subscribe to webhook fields: `messages`, `message_deliveries`, `message_reads`.

### 3. Vercel / Cloud Run Deployment
1. Import repository into Vercel or Cloud Run.
2. Add all variables from `.env.example` to the Environment Variables settings.
3. Run `npm run build` as the build command.
4. Set Root Directory to `.`.
