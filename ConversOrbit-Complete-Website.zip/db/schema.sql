-- ConversOrbit Multi-Tenant SaaS Database Schema
-- Compatible with PostgreSQL 14+, Supabase, Neon, Cloud SQL

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Organizations (Tenants)
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    plan_id VARCHAR(50) NOT NULL DEFAULT 'free',
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    timezone VARCHAR(100) DEFAULT 'UTC',
    currency VARCHAR(10) DEFAULT 'USD',
    contacts_limit INT DEFAULT 100,
    messages_limit_monthly INT DEFAULT 500,
    chatbots_limit INT DEFAULT 1,
    team_seats_limit INT DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Users & Memberships
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'agent', -- superadmin, owner, admin, agent, viewer
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. WhatsApp Cloud API Integrations
CREATE TABLE whatsapp_integrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID UNIQUE NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    mode VARCHAR(20) DEFAULT 'demo', -- demo or live
    phone_number_id VARCHAR(100),
    waba_id VARCHAR(100),
    encrypted_access_token TEXT,
    webhook_verify_token VARCHAR(255),
    display_phone_number VARCHAR(50),
    quality_rating VARCHAR(20) DEFAULT 'GREEN',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Contacts CRM
CREATE TABLE contacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    email VARCHAR(255),
    tags TEXT[] DEFAULT '{}',
    source VARCHAR(100) DEFAULT 'WhatsApp',
    notes TEXT,
    custom_fields JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_active TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_contacts_org_phone ON contacts (organization_id, phone);

-- 5. Conversations & Shared Inbox
CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    contact_id UUID NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
    status VARCHAR(50) DEFAULT 'open', -- open, pending, resolved, bot
    assigned_to UUID REFERENCES users(id) ON DELETE SET NULL,
    unread_count INT DEFAULT 0,
    last_message TEXT,
    last_message_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    tags TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_conversations_org_status ON conversations (organization_id, status);

-- 6. Messages
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender VARCHAR(20) NOT NULL, -- contact, agent, bot, system
    sender_name VARCHAR(100),
    content TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'sent', -- sending, sent, delivered, read, failed
    is_demo BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_messages_conv ON messages (conversation_id, created_at);

-- 7. Broadcast Campaigns
CREATE TABLE campaigns (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    objective TEXT,
    status VARCHAR(50) DEFAULT 'draft', -- draft, scheduled, running, completed, cancelled
    target_filter_type VARCHAR(50) DEFAULT 'all',
    target_filter_value VARCHAR(100),
    recipient_count INT DEFAULT 0,
    template_header TEXT,
    template_body TEXT NOT NULL,
    template_footer TEXT,
    button_label VARCHAR(100),
    button_url TEXT,
    scheduled_at TIMESTAMP WITH TIME ZONE,
    sent_count INT DEFAULT 0,
    delivered_count INT DEFAULT 0,
    read_count INT DEFAULT 0,
    replied_count INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. Visual Chatbot Flows
CREATE TABLE chatbot_flows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    triggers TEXT[] DEFAULT '{}',
    nodes JSONB NOT NULL DEFAULT '[]',
    total_triggers INT DEFAULT 0,
    completion_rate NUMERIC(5,2) DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. Workflows & Executions
CREATE TABLE workflows (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    trigger_config JSONB NOT NULL,
    actions JSONB NOT NULL DEFAULT '[]',
    execution_count INT DEFAULT 0,
    last_executed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE workflow_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    workflow_id UUID REFERENCES workflows(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL,
    trigger_details TEXT,
    executed_actions JSONB DEFAULT '[]',
    duration_ms INT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 10. Multi-Tenant Row Level Security (RLS)
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE chatbot_flows ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflows ENABLE ROW LEVEL SECURITY;

-- Sample RLS Policy for Contacts
CREATE POLICY tenant_isolation_contacts ON contacts
    FOR ALL
    USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::UUID);
